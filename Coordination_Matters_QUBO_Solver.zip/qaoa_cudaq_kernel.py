import cudaq
HALF_PI = 1.5707963267948966
@cudaq.kernel
def qaoa(n: int, p: int, gam: list[float], bet: list[float], hz: list[float], zi: list[int],
         zj: list[int], jz: list[float], xy: int, init_ones: list[int], wa: list[int], wb: list[int],
         wth: list[float], pa: list[int], pb: list[int]):
    q = cudaq.qvector(n)
    if xy == 0:
        h(q)
    else:
        for k in range(len(init_ones)):
            x(q[init_ones[k]])
        for k in range(len(wa)):
            h(q[wa[k]]); h(q[wb[k]])
            x.ctrl(q[wa[k]], q[wb[k]]); rz(wth[k], q[wb[k]]); x.ctrl(q[wa[k]], q[wb[k]])
            h(q[wa[k]]); h(q[wb[k]])
            rx(HALF_PI, q[wa[k]]); rx(HALF_PI, q[wb[k]])
            x.ctrl(q[wa[k]], q[wb[k]]); rz(wth[k], q[wb[k]]); x.ctrl(q[wa[k]], q[wb[k]])
            rx(-HALF_PI, q[wa[k]]); rx(-HALF_PI, q[wb[k]])
    for L in range(p):
        for k in range(n):
            rz(2.0 * gam[L] * hz[k], q[k])
        for k in range(len(zi)):
            x.ctrl(q[zi[k]], q[zj[k]]); rz(2.0 * gam[L] * jz[k], q[zj[k]]); x.ctrl(q[zi[k]], q[zj[k]])
        if xy == 0:
            for k in range(n):
                rx(2.0 * bet[L], q[k])
        else:
            for k in range(len(pa)):
                h(q[pa[k]]); h(q[pb[k]])
                x.ctrl(q[pa[k]], q[pb[k]]); rz(2.0 * bet[L], q[pb[k]]); x.ctrl(q[pa[k]], q[pb[k]])
                h(q[pa[k]]); h(q[pb[k]])
                rx(HALF_PI, q[pa[k]]); rx(HALF_PI, q[pb[k]])
                x.ctrl(q[pa[k]], q[pb[k]]); rz(2.0 * bet[L], q[pb[k]]); x.ctrl(q[pa[k]], q[pb[k]])
                rx(-HALF_PI, q[pa[k]]); rx(-HALF_PI, q[pb[k]])
